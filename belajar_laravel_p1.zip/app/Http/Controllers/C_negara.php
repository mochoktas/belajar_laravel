<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class C_negara extends Controller
{
    //
}
