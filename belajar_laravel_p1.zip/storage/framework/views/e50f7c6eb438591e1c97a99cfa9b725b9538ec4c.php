

<?php $__env->startSection('page_title','adminLTE 3 | Buku'); ?>

<?php $__env->startSection('title','Tambah buku'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#">Home</a></li>
<li class="breadcrumb-item active">Blank Page</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conten'); ?>
<div class="card">
        <div class="card-header">
          <h3 class="card-title">Buku</h3>

          
        </div>
        <div class="card-body">
        <form  action="/buku/insertData" method="post">
        <?php echo csrf_field(); ?>
                <div class="card-body">
                  
                    <label for="exampleInputEmail1">No ISBN</label>
                    <input type="text" name="no_isbn" class="form-control" id="exampleInputEmail1" placeholder="NO ISBN">
                  
                    
                    <label>Judul Buku</label>
                    <textarea name = "judul" class="form-control" rows="3" maxlenght="100" placeholder="Judul Buku"></textarea>
                         
                    <label >Tahun Terbit</label>
                    <input type="text" name="tahun" class="form-control" maxlenght="4" id="exampleInputEmail1" placeholder="Tahun Terbit">
                  
                    <label>Penulis</label>
                    <textarea name = "penulis" class="form-control" rows="3" maxlenght="100" placeholder="Penulis"></textarea>
                     
                    <label >Cetakan ke</label>
                    <input type="text" name="cetakan" class="form-control" maxlenght="3" id="exampleInputEmail1" placeholder="Cetakan Ke">

                    <label >Harga</label>
                    <input type="text" name="harga" class="form-control" maxlenght="11" id="exampleInputEmail1" placeholder="Harga">

                    <label >Jumlah eksemplar</label>
                    <input type="text" name="jml_eksemplar" class="form-control" maxlenght="4" id="exampleInputEmail1" placeholder="Jumlah">
                  
                    <div class="form-group">
                    <label for="exampleInputEmail1">Kategori Buku</label>    
                        <div class="form-check">
                          <input class="form-check-input" type="radio" value="1" name="radio1">
                          <label class="form-check-label">Fiksi</label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="radio" name="radio1" value="0" checked>
                          <label class="form-check-label">Non Fiksi</label>
                        </div>
                        
                    </div> 

                    <label>Jenis Buku</label>
                        <select class="form-control" name="id_jb">
                        <?php $__currentLoopData = $jb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                        <option value="<?php echo e($jb->id_jb); ?>">
                        
                         <?php echo e($jb->nama_jb); ?>

                         
                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        </select>

                    <label>Penerbit</label>
                        <select class="form-control" name="id_penerbit">
                        <?php $__currentLoopData = $pnb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pnb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                        <option value="<?php echo e($pnb->id_penerbit); ?>">
                        
                         <?php echo e($pnb->nama_penerbit); ?>

                         
                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        </select>
                    
                    <label>Bahasa</label>
                        <select class="form-control" name="id_bhs">
                        <?php $__currentLoopData = $bhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                        <option value="<?php echo e($bhs->id_bhs); ?>">
                        
                         <?php echo e($bhs->nama_bhs); ?>

                         
                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        </select>
                    
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
        </form>
        
        
        <!-- /.card-footer-->
</div>

      <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/tambah_buku.blade.php ENDPATH**/ ?>