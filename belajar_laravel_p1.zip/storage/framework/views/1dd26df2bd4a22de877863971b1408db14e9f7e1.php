

<?php $__env->startSection('page_title','adminLTE 3 | Blank page'); ?>

<?php $__env->startSection('title','Tambah Jenis Buku'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#">Home</a></li>
<li class="breadcrumb-item active">Blank Page</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conten'); ?>
<div class="card">
        <div class="card-header">
          <h3 class="card-title">Jenis Buku</h3>

          <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                <i class="fas fa-minus"></i></button>
              <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fas fa-times"></i></button>
          </div>
        </div>
        <div class="card-body">
        <form  action="/jenisbuku/insertData" method="post">
        <?php echo csrf_field(); ?>
                <div class="card-body">
                  
                    <label for="exampleInputEmail1">ID Jenis Buku</label>
                    <input type="text" name="id_jb" class="form-control" id="exampleInputEmail1" placeholder="ID Jenis Buku">
                  
                    <label for="exampleInputEmail1">Nama Jenis Buku</label>
                    <input type="text" name="nama_jb" class="form-control" id="exampleInputEmail1" placeholder="Nama">
                 
                  
                    <label for="exampleInputEmail1">Kode Jenis Buku</label>
                    <input type="text" name="kode_jb" class="form-control" id="exampleInputEmail1" placeholder="Kode">
                  
                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
        </form>
        
        
        <!-- /.card-footer-->
</div>
      <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/tambah_jenis_buku.blade.php ENDPATH**/ ?>