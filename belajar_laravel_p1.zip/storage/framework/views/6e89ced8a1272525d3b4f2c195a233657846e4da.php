

<?php $__env->startSection('page_title','adminLTE 3 | Blank page'); ?>

<?php $__env->startSection('title','HISTORY'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#">Home</a></li>
<li class="breadcrumb-item active">Blank Page</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conten'); ?>
<div class="card">
        <div class="card-header">
          <h3 class="card-title">History Peminjaman Buku Berdasarkan ID BUKU</h3>

          <div class="card-tools">
              
          </div>
        </div>
        <div class="card-body">
        <form  action="/historyPeminjaman/cariBukuUp" method="get">
                <input type="text" name="inp" class="form-control" id="exampleInputEmail1"  placeholder="Cari ID Buku" >
                
                <button type="submit" class="btn btn-primary">Search</button>
                
        </form>
        <table class="table table-bordered">
                  <thead>                  
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>No ISBN</th>
                      <th>NIS_NIP</th>
                      <th>Nama Anggota</th>
                      <th>tanggal pinjam</th>
                      <th>tanggal kembali</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <tr> 
                         <td><?php echo e($loop->iteration); ?></td>
                         <td><?php echo e($ag->no_isbn); ?></td> 
                         <td><?php echo e($ag->nis_nip); ?></td> 
                         <td><?php echo e($ag->nama_anggota); ?></td>
                         <td><?php echo e($ag->tgl_pinjam); ?></td>
                         <td><?php echo e($ag->tgl_kembali); ?></td>
                      </tr> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                  </tbody>
                </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          Footer
        </div>
        <!-- /.card-footer-->
</div>
      <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/history_peminjaman_buku.blade.php ENDPATH**/ ?>