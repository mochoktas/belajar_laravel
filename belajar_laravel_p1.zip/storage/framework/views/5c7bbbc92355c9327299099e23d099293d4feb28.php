

<?php $__env->startSection('page_title','adminLTE 3 | Blank page'); ?>

<?php $__env->startSection('title','Pengembalian'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#">Home</a></li>
<li class="breadcrumb-item active">Blank Page</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conten'); ?>
<div class="card">
        <div class="card-header">
          <h3 class="card-title">pengembalian</h3>

          <div class="card-tools">
              
          </div>
        </div>
        <div class="card-body">
        <form  action="/pengembalian/cariAnggota" method="get">
                <input type="text" name="nama_anggota" class="form-control" id="exampleInputEmail1"  placeholder="Cari Nama Anggota" >
                
                <button type="submit" class="btn btn-primary">Search</button>
                
        </form>
        <table class="table table-bordered">
                  <thead>                  
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>NIS_NIP</th>
                      <th>Nama Anggota</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <tr> 
                         <td><?php echo e($loop->iteration); ?></td>
                         <td><?php echo e($ag->nis_nip); ?></td> 
                         <td><?php echo e($ag->nama_anggota); ?></td>
                         <td><a href='/pengembalian/listPengembalianBuku/<?php echo e($ag->nis_nip); ?>'>
                               <button> kembalikan buku </button> 
                             </a> 
                         </td> 
                      </tr> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                  </tbody>
                </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          Footer
        </div>
        <!-- /.card-footer-->
</div>
      <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/blank_page_pengembalian.blade.php ENDPATH**/ ?>