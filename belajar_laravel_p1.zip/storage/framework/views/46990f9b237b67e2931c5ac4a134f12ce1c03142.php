

<?php $__env->startSection('page_title','adminLTE 3 | Blank page'); ?>

<?php $__env->startSection('title','Tambah Peminjaman'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#">Home</a></li>
<li class="breadcrumb-item active">Blank Page</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conten'); ?>
<div class="card">
        <div class="card-header">
          <h3 class="card-title">Peminjaman</h3>

          <div class="card-tools">
              
          </div>
        </div>
        <div class="card-body">
        <form  action="/peminjaman/insertData" method="post">
        <?php echo csrf_field(); ?>
                <div class="card-body">
                  
                    <label for="exampleInputEmail1">ID Peminjaman</label>
                        <input type="text" name="id_peminjaman" class="form-control" id="exampleInputEmail1" placeholder="ID Peminjaman ">

                    <label for="exampleInputEmail1">NIS NIP</label>
                    <input type="text" name="nis_nip" class="form-control" id="exampleInputEmail1" value="<?php echo e($data[0]->nis_nip); ?>" placeholder="ID Jenis Buku" readonly>
                  
                    <label for="exampleInputEmail1">Nama Anggota</label>
                    <input type="text" name="nama_anggota" class="form-control" id="exampleInputEmail1" value="<?php echo e($data[0]->nama_anggota); ?>" placeholder="Nama" readonly>
                 
                    <label for="exampleInputEmail1">NIP Pegawai</label>
                    <input type="text" name="nip" class="form-control" id="exampleInputEmail1" value="<?php echo e($pegawai->nip); ?>" placeholder="NIP" readonly>
                  
                   
                    <label for="exampleInputEmail1">Jumlah Buku</label>
                        <input type="text" name="jml_buku" class="form-control" id="exampleInputEmail1" placeholder="Jumlah ">



                  
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
        </form>
        
        
        <!-- /.card-footer-->
</div>
      <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/tambahPeminjaman.blade.php ENDPATH**/ ?>