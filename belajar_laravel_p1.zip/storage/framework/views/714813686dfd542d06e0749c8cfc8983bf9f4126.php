

<?php $__env->startSection('page_title','adminLTE 3 | Blank page'); ?>

<?php $__env->startSection('title','HISTORY'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#">Home</a></li>
<li class="breadcrumb-item active">Blank Page</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conten'); ?>
<div class="card">
        <div class="card-header">
          <h3 class="card-title">History Peminjaman Buku Berdasarkan ID atau Nama Anggota</h3>

          <div class="card-tools">
              
          </div>
        </div>
        <div class="card-body">
        <form  action="/historyPeminjaman/cariAnggotaUp" method="get">
                <input type="text" name="inp" class="form-control" id="exampleInputEmail1"  placeholder="Cari ID atau Nama Anggota" >
                
                <button type="submit" class="btn btn-primary">Search</button>
                
        </form>
        <table class="table table-bordered">
                  <thead>                  
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>Nis Nip</th>
                      <th>Nama Anggota</th>
                      <th>No ISBN</th>
                      <th>Judul Buku</th>
                      <th>Status pinjam</th>
                      <th>tanggal pinjam</th>
                      <th>tanggal kembali</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <tr> 
                         <td><?php echo e($loop->iteration); ?></td>
                         <td><?php echo e($pg->nis_nip); ?></td> 
                         <td><?php echo e($pg->nama_anggota); ?></td> 
                         <td><?php echo e($pg->no_isbn); ?></td> 
                         <td><?php echo e($pg->judul_buku); ?></td> 
                         <td><?php echo e($pg->status_peminjaman); ?></td>
                         <td><?php echo e($pg->tgl_pinjam); ?></td>
                         <td><?php echo e($pg->tgl_kembali); ?></td>
                      </tr> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                  </tbody>
                </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          Footer
        </div>
        <!-- /.card-footer-->
</div>
      <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/history_peminjaman_anggota.blade.php ENDPATH**/ ?>