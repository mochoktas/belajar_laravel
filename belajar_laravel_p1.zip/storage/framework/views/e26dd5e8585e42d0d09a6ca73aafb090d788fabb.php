

<?php $__env->startSection('page_title','adminLTE 3 | Blank page'); ?>

<?php $__env->startSection('title','HISTORY'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#">Home</a></li>
<li class="breadcrumb-item active">Blank Page</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conten'); ?>
<div class="card">
        <div class="card-header">
          <h3 class="card-title">History Peminjaman Buku</h3>

          <div class="card-tools">
              
          </div>
        </div>
        <div class="card-body">
        
                <a class="btn btn-primary btn-block" href="/historyPeminjaman/cariBuku" method="GET">Cari Berdasarkan ID BUKU</a>
                <a class="btn btn-primary btn-block" href="/historyPeminjaman/cariAnggota" method="GET">Cari Berdasarkan ID Anggota atau Nama Anggota</a>
                
                
        
        
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          Footer
        </div>
        <!-- /.card-footer-->
</div>
      <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/history_peminjaman_index.blade.php ENDPATH**/ ?>