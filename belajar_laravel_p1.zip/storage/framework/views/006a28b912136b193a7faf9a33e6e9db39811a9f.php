

<?php $__env->startSection('page_title','adminLTE 3 | Blank page'); ?>

<?php $__env->startSection('title','Tambah Penerimaan buku'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#">Home</a></li>
<li class="breadcrumb-item active">Blank Page</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conten'); ?>
<div class="card">
        <div class="card-header">
          <h3 class="card-title">Penerimaan</h3>

          
        </div>
        <div class="card-body">
        <form  action="/penerimaan/insertData" method="post">
        <?php echo csrf_field(); ?>
                <div class="card-body">
                  
                    <label for="exampleInputEmail1">ID Penerimaan</label>
                    <input type="text" name="id_penerimaan" class="form-control" id="exampleInputEmail1" placeholder="ID Penerimaan">
                  
                    
                    <label>Keterangan</label>
                    <textarea name = "keterangan" class="form-control" rows="3" maxlenght="100" placeholder="Enter ..."></textarea>
                         
                    

                    <label for="exampleInputEmail1">Jumlah Buku</label>
                    <input type="text" name="jml_buku_diterima" class="form-control" id="exampleInputEmail1" placeholder="Jumlah ">
                 
                    <label for="exampleInputEmail1">NIP Pegawai</label>
                    <input type="text" name="nip" class="form-control" id="exampleInputEmail1" value="<?php echo e($pegawai->nip); ?>" placeholder="NIP" readonly>
                  
                    
                    <label>Asal</label>
                        <select class="form-control" name="id_asal">
                        <?php $__currentLoopData = $asal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                        <option value="<?php echo e($asl->id_asal); ?>">
                        
                        <?php echo e($asl->asal); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        </select>
                    
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
        </form>
        
        
        <!-- /.card-footer-->
</div>

      <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/tambah_penerimaan.blade.php ENDPATH**/ ?>