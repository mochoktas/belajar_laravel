<!-- gunakan template master --> 
 
 

<!-- Bagian Judul --> 
<!-- jika isi bagian / section sedikit, dapat ditulis seperti ini --> 
<?php $__env->startSection('judul', 'Halaman Tentang'); ?> 
 
<!-- isi konten --> 
<!-- jika isi section panjang, maka penulisan dilakukan seperti ini --> 
<?php $__env->startSection('konten'); ?> 
    <p>Ini adalah halaman tentang</p> 
    <p>testtesttesttest</p> 
 
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/tentang.blade.php ENDPATH**/ ?>