

<?php $__env->startSection('page_title','adminLTE 3 | Bahasa'); ?>

<?php $__env->startSection('title','Bahasa'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#">Home</a></li>
<li class="breadcrumb-item active">Blank Page</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conten'); ?>
<div class="card">
        <div class="card-header">
          <h3 class="card-title"> Data Bahasa</h3>

          <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                <i class="fas fa-minus"></i></button>
              <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fas fa-times"></i></button>
          </div>
        </div>
        <div class="card-body">
        <a class="btn btn-primary btn-block" href="/bahasa/tambahBahasa" method="GET">Tambah Data Bahasa</a>
        <table class="table table-bordered">
                  <thead>                  
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>ID</th>
                      <th>Nama </th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $bahasa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <tr> 
                         <td><?php echo e($loop->iteration); ?></td>
                         <td><?php echo e($jb->id_bhs); ?></td> 
                         <td><?php echo e($jb->nama_bhs); ?></td>
                         
                      </tr> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                  </tbody>
                </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          Footer
        </div>
        <!-- /.card-footer-->
</div>
      <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/bahasa_page.blade.php ENDPATH**/ ?>