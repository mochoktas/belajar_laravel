<!DOCTYPE html> 
<head> 
    <title>Halaman Detail Penawaran</title> 
</head> 
<body> 
    <h1>Data Detail Penawaran</h1> 
    <br> 
    <br> 
    <br> 
    <table border="1" width="100%"> 
    <tr> 
        <th>nomor</th>
        <th>id penawaran</th> 
        <th>Nama calon konsumen</th>
        <th>Status Penawaran</th>
    </tr> 
    <?php $__currentLoopData = $detail_penawaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
        <tr> 
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($dtl->id_penawaran); ?></td> 
            <td><?php echo e($dtl->calon_konsumen->nama_calon_konsumen); ?></td> 
            <td><?php echo e($dtl->status_penawaran); ?></td>
        </tr> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </table> 
</body> 
</html> <?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/detail_penawaran.blade.php ENDPATH**/ ?>