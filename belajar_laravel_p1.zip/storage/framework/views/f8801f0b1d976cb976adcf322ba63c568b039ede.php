

<?php $__env->startSection('page_title','adminLTE 3 | Eksemplar Buku'); ?>

<?php $__env->startSection('title','Tambah Eksemplar buku'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#">Home</a></li>
<li class="breadcrumb-item active">Blank Page</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conten'); ?>
<div class="card">
        <div class="card-header">
          <h3 class="card-title">Eksemplar Buku</h3>

          
        </div>
        <div class="card-body">
        <form  action="/eksemplar_buku/insertData" method="post">
        <?php echo csrf_field(); ?>
                <div class="card-body">
                  
                    <label for="exampleInputEmail1">Kode Buku</label>
                    <input type="text" name="kode_buku" class="form-control" id="exampleInputEmail1" placeholder="Kode Buku">
                  
                    <div class="form-group">
                    <label for="exampleInputEmail1">Status</label>    
                        <div class="form-check">
                          <input class="form-check-input" type="radio" value="1" name="radio1">
                          <label class="form-check-label">aktif</label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="radio" name="radio1" value="0" checked>
                          <label class="form-check-label">tidak aktif</label>
                        </div>
                        
                    </div> 

                    <div class="form-group">
                    <label for="exampleInputEmail1">Kondisi</label>    
                        <div class="form-check">
                          <input class="form-check-input" type="radio" value="1" name="radio2">
                          <label class="form-check-label">Bagus</label>
                        </div>
                        <div class="form-check">
                          <input class="form-check-input" type="radio" name="radio2" value="0" checked>
                          <label class="form-check-label">Jelek</label>
                        </div>
                        
                    </div> 

                    <label>Buku</label>
                        <select class="form-control" name="no_isbn">
                        <?php $__currentLoopData = $bk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                        <option value="<?php echo e($bhs->no_isbn); ?>">
                        
                         <?php echo e($bhs->judul_buku); ?>

                         
                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        </select>
                    
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
        </form>
        
        
        <!-- /.card-footer-->
</div>

      <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/tambah_eksemplar_buku.blade.php ENDPATH**/ ?>