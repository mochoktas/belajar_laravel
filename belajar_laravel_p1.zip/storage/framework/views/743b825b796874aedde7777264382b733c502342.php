

<?php $__env->startSection('page_title','adminLTE 3 | Blank page'); ?>

<?php $__env->startSection('title','Pengembalian'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#">Home</a></li>
<li class="breadcrumb-item active">Blank Page</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conten'); ?>
<div class="card">
        <div class="card-header">
          <h3 class="card-title">Pengembalian</h3>

          <div class="card-tools">
              
          </div>
        </div>
        <div class="card-body">
        
        <table class="table table-bordered">
                  <thead>                  
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>ID Peminjaman</th>
                      <th>NIS_NIP</th>
                      <th>kode buku</th>
                      <th>judul buku</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                      <tr> 
                         <td><?php echo e($loop->iteration); ?></td>
                         <td><?php echo e($pg->id_peminjaman); ?></td> 
                         <td><?php echo e($pg->nis_nip); ?></td>
                         <td><?php echo e($pg->kode_buku); ?></td>
                         <td><?php echo e($pg->judul_buku); ?></td>
                         <td><a href='/pengembalian/insertPengembalian/<?php echo e($pg->id_peminjaman); ?>/<?php echo e($pg->kode_buku); ?>/<?php echo e($pg->nis_nip); ?>'>
                               <button> kembalikan buku </button> 
                             </a> 
                         </td> 
                      </tr> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                  </tbody>
                </table>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          Footer
        </div>
        <!-- /.card-footer-->
</div>
      <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/listPengembalianBuku.blade.php ENDPATH**/ ?>