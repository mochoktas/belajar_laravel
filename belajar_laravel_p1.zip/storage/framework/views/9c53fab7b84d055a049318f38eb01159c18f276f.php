<!DOCTYPE html> 
<head> 
    <title>Halaman Customer</title> 
</head> 
<body> 
    <h1>Data Customer</h1> 
    <br> 
    <a href="/customer/tambahCustomer"><b>Tambah Data Customer</b></a> 
    <br> 
    <br> 
    <table border="1" width="100%"> 
    <tr> 
        <th>Id Customer</th> 
        <th>Nama Depan</th> 
        <th>Nama Belakang</th> 
        <th>Phone</th> 
        <th>Email</th> 
        <th>Alamat</th> 
        <th>Kota</th> 
        <th>Provinsi</th> 
        <th>Kode Pos</th> 
        <th>Action</th> 
    </tr> 
    <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
        <tr> 
            <td><?php echo e($data->customer_id); ?></td> 
            <td><?php echo e($data->first_name); ?></td> 
            <td><?php echo e($data->last_name); ?></td> 
            <td><?php echo e($data->phone); ?></td> 
            <td><?php echo e($data->email); ?></td> 
           <td><?php echo e($data->street); ?></td>  
            <td><?php echo e($data->city); ?></td>  
            <td><?php echo e($data->state); ?></td> 
            <td><?php echo e($data->zip_code); ?></td> 
            <td><a href='/customer/editCustomer/<?php echo e($data->customer_id); ?>'> 
                    <button> edit </button> 
                </a> 
            </td> 
        </tr> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </table> 
     
</body> 
</html>             <?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/customer_page.blade.php ENDPATH**/ ?>