<!-- <!DOCTYPE html> 
<head> 
    <title>Belajar Laravel</title> 
</head> 
<body> 
    <h3>Mengirim data dari Controller ke View</h3> 
    <br> 
    <p>Menerima data: <?php echo $nama;?></p> 
</body> 
 
</html>  -->

<!DOCTYPE html> 
<head> 
    <title>Belajar Laravel</title> 
</head> 
<body> 
    <h3>Mengirim data dari Controller ke View</h3> 
    <br> 
    <p>Menerima data: {{ $nama }}</p> 
</body> 
 
</html> 

 